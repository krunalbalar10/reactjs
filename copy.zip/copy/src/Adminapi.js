export default function getUrl() {
    return "https://theeasylearnacademy.com/school/"
}

export const COOKIENAME = ['theeasylearnacademy'];

// export function getImageUrl() {
//     return getUrl() + "images/";
// }

// // name of the cookie file to be use everywhere
// export const COOKIENAME = ['dholerasmartcities'];
